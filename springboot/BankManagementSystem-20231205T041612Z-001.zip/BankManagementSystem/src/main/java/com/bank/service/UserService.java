package com.bank.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.entity.User;
import com.bank.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	UserRepository userRepo;
	
	public User addUser(User user)
	{
		User user1 = userRepo.save(user);
		return user1;
	}
	public Optional<User> getUserById (int id) 
	{
		Optional<User> user1 = userRepo.findById(id);
		return user1;
		
		
	}
	public List<User> getUsers()
	{
		List<User> u1 = userRepo.findAll();
		return u1;
	}

	public String deleteUser(int id)
	{
		if(userRepo.existsById(id)) {
		userRepo.deleteById(id);
		return "User Deleted";
	}
	else 
	{
		return "no user found";
	}
		}
	
	public String editUser(int id, User user)
	{
		if(userRepo.existsById(id))
		{
			User use1 = userRepo.findById(id).get();
			use1.setName(user.getName());
			use1.setAcNo(user.getAcNo());
			use1.setBalance(user.getBalance());
			use1.setRecName(user.getRecName());
			use1.setRecPaid(user.getRecPaid());
			use1.setPass(user.getPass());
			userRepo.save(use1);
			return "User Upadted";
		}
		else 
		{
			return "No user found";
		}
}
}
