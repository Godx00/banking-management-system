package com.bank.controller;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.entity.User;
import com.bank.service.UserService;

@CrossOrigin
@RequestMapping("/api/v1/")
@RestController
public class UserController {
	@Autowired
	UserService usSer;
	@PostMapping("/user")
	public ResponseEntity<User> addProduct(@RequestBody User user)
	{
		User pro = usSer.addUser(user);
		return new ResponseEntity<User>(pro, HttpStatus.OK);
	}
	@GetMapping("/user/{id}")
	public ResponseEntity<Optional<User>> getUserById(@PathVariable int id)
	{
		return new ResponseEntity<Optional<User>>(usSer.getUserById(id),HttpStatus.OK);
	}
	
	@GetMapping("/user")
	public ResponseEntity<List<User>> getUsers()
	{
		return new ResponseEntity<List<User>>(usSer.getUsers(),HttpStatus.OK);
	}
	@DeleteMapping("/user/{id}")
	public ResponseEntity<String> deleteUser(@PathVariable int id)
	{
		return new ResponseEntity<String>(usSer.deleteUser(id),HttpStatus.OK);
	}
	@PutMapping("/user/{id}")
	public ResponseEntity<String> editUser (@PathVariable int id ,@RequestBody User user)
	{
		return new ResponseEntity<String>(usSer.editUser(id, user),HttpStatus.OK);
	}

}
